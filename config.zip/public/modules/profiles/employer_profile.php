<?php
ob_start();
$branches = !empty($employer['branches']) ? json_decode($employer['branches'], true) : [];
if (!is_array($branches)) $branches = [];
$workShifts = !empty($employer['work_shifts']) ? json_decode($employer['work_shifts'], true) : [];
if (!is_array($workShifts)) $workShifts = [];

if (!function_exists('parseJobShiftHours')) {
    function parseJobShiftHours($str) {
        $start = ''; $end = ''; $name = '';
        $str = trim((string)$str);
        if (preg_match('/^(.*?)\((.*?)\)$/u', $str, $m)) {
            $name = trim($m[1]);
            $timePart = trim($m[2]);
        } else {
            $name = '';
            $timePart = $str;
        }
        if (preg_match('/^[\d\s:hH\-–\.\/]+$/u', $name)) {
            $name = '';
        }
        if (preg_match_all('/(\d{1,2})(?:[h:H:](\d{1,2})?)?/u', $timePart, $matches, PREG_SET_ORDER)) {
            if (isset($matches[0])) {
                $h = str_pad($matches[0][1], 2, '0', STR_PAD_LEFT);
                $m = !empty($matches[0][2]) ? str_pad($matches[0][2], 2, '0', STR_PAD_LEFT) : '00';
                $start = "$h:$m";
            }
            if (isset($matches[1])) {
                $h = str_pad($matches[1][1], 2, '0', STR_PAD_LEFT);
                $m = !empty($matches[1][2]) ? str_pad($matches[1][2], 2, '0', STR_PAD_LEFT) : '00';
                $end = "$h:$m";
            }
        }
        return [
            'name' => $name,
            'start' => !empty($start) ? $start : '08:00',
            'end' => !empty($end) ? $end : '17:00'
        ];
    }
}
?>

<div style="width: 100%; max-width: 100%; margin: 0 auto; padding-bottom: 2.5rem;">
    <div style="margin-bottom: 2rem;">
        <h1 style="font-size: 1.6rem; font-weight: 800; color: var(--dark);">hồ sơ doanh nghiệp & hệ thống cơ sở</h1>
        <p style="color: var(--slate-500); font-size: 0.95rem;">Cập nhật thông tin công ty, trụ sở chính và các chi nhánh / cơ sở làm việc kèm định vị Google Maps</p>
    </div>

    <div class="card">
        <form action="<?= url('/employer/company-profile/update') ?>" method="POST" id="employerProfileForm" enctype="multipart/form-data" data-unsaved-bar="true">
            <!-- Header thông tin đại diện -->
            <div style="display: flex; gap: 1.5rem; align-items: center; margin-bottom: 2rem; padding-bottom: 1.5rem; border-bottom: 1px solid var(--slate-200); flex-wrap: wrap;">
                <?php
                    $empAvatar = getAvatarUrl($employer['avatar_url'] ?? '', 'EMPLOYER');
                    $fallbackEmpAvatar = getAvatarUrl('', 'EMPLOYER');
                ?>
                <div style="text-align: center; flex-shrink: 0;">
                    <img id="employer_avatar_img" src="<?= htmlspecialchars($empAvatar) ?>" alt="logo" style="width: 88px; height: 88px; border-radius: var(--radius); object-fit: cover; border: 2px solid #0d9488; display: block;" onerror="this.src='<?= htmlspecialchars($fallbackEmpAvatar) ?>'">
                    <input type="file" name="avatar_file" id="employer_avatar_file" accept="image/png,image/jpeg,image/webp,image/jpg" style="display:none;" onchange="previewEmployerAvatar(this)">
                    <button type="button" onclick="document.getElementById('employer_avatar_file').click()" class="btn btn-sm" style="margin-top: 0.5rem; font-size: 0.75rem; padding: 0.3rem 0.6rem; border-radius: 20px; background: #0d9488; color: #ffffff; border: 1px solid #0d9488; font-weight: 700; display: inline-flex; align-items: center; gap: 0.3rem;">
                        <?= icon('camera', '', 12) ?> <span>Đổi logo</span>
                    </button>
                </div>
                <div>
                    <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--dark);"><?= htmlspecialchars($employer['employer_name']) ?></h3>
                    <div style="display: flex; gap: 0.5rem; margin-top: 0.35rem; align-items: center; flex-wrap: wrap;">
                        <span class="badge <?= ($employer['verification_status'] ?? '') === 'verified' ? 'badge-success' : 'badge-warning' ?>">
                            <?= ($employer['verification_status'] ?? '') === 'verified' ? icon('check', '', 12) . ' <span>Đã xác minh GPKD</span>' : '<span>Đang chờ duyệt</span>' ?>
                        </span>
                        <span class="badge badge-warning"><?= icon('star_fill', '', 12) ?> <span><?= $employer['avg_rating'] ?? '5.0' ?> (<?= $employer['total_reviews'] ?? 0 ?> đánh giá)</span></span>
                    </div>
                </div>
            </div>

            <!-- Thông tin pháp lý & Liên hệ chung -->
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Tên doanh nghiệp / Cửa hàng *</label>
                    <input type="text" name="employer_name" value="<?= htmlspecialchars($employer['employer_name'] ?? '') ?>" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Loại hình doanh nghiệp</label>
                    <select name="employer_type" class="form-control">
                        <option value="enterprise" <?= ($employer['employer_type'] ?? '') === 'enterprise' ? 'selected' : '' ?>>Doanh nghiệp lớn (Enterprise)</option>
                        <option value="sme" <?= ($employer['employer_type'] ?? '') === 'sme' ? 'selected' : '' ?>>Doanh nghiệp vừa và nhỏ (SME)</option>
                        <option value="household" <?= ($employer['employer_type'] ?? '') === 'household' ? 'selected' : '' ?>>Hộ kinh doanh cá thể (Household)</option>
                        <option value="startup" <?= ($employer['employer_type'] ?? '') === 'startup' ? 'selected' : '' ?>>Khởi nghiệp (Startup)</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Người đại diện pháp luật</label>
                    <input type="text" name="representative_name" value="<?= htmlspecialchars($employer['representative_name'] ?? '') ?>" class="form-control" placeholder="Họ và tên người đại diện">
                </div>
                <div class="form-group">
                    <label class="form-label">Số GPKD / Mã số thuế *</label>
                    <input type="text" name="business_license_number" value="<?= htmlspecialchars($employer['business_license_number'] ?? '') ?>" class="form-control" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Lĩnh vực hoạt động</label>
                    <input type="text" name="business_field" value="<?= htmlspecialchars($employer['business_field'] ?? '') ?>" class="form-control" placeholder="F&B, Bán lẻ, Sản xuất, CNTT...">
                </div>
                <div class="form-group">
                    <label class="form-label">Email liên hệ tuyển dụng</label>
                    <input type="email" name="contact_email" value="<?= htmlspecialchars($employer['contact_email'] ?? '') ?>" class="form-control">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Số điện thoại Hotline</label>
                    <input type="text" name="phone_number" value="<?= htmlspecialchars($employer['phone_number'] ?? '') ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Website doanh nghiệp</label>
                    <input type="url" name="website_url" value="<?= htmlspecialchars($employer['website_url'] ?? '') ?>" class="form-control" placeholder="https://...">
                </div>
            </div>

            <!-- TRỤ SỞ CHÍNH -->
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.25rem; margin-top: 1.5rem; margin-bottom: 1.5rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 0.5rem;">
                    <div style="font-weight: 700; color: #0f172a; font-size: 1rem; display: flex; align-items: center; gap: 0.4rem;">
                        <?= icon('building', '', 16) ?>
                        <span>địa chỉ Trụ sở chính *</span>
                        <span class="badge badge-primary" style="font-size: 0.75rem;">Trụ sở chính</span>
                    </div>
                    <?php
                        $mainMapUrl = !empty($employer['map_url']) ? $employer['map_url'] : (!empty($employer['address']) ? getGoogleMapsUrl($employer['address']) : '');
                    ?>
                    <?php if (!empty($mainMapUrl)): ?>
                        <a href="<?= htmlspecialchars($mainMapUrl) ?>" target="_blank" class="btn btn-outline btn-sm" style="background:#0d9488; font-size: 0.8rem; color: #ffffff; border-color: #0d9488; font-weight: 700; display: inline-flex; align-items: center; gap: 0.3rem;">
                            <?= icon('location', '', 13) ?> <span>Xem vị trí trên Google Maps</span>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="form-group" style="margin-bottom: 0.85rem;">
                    <label class="form-label" style="font-size: 0.85rem;">địa chỉ Trụ sở *</label>
                    <input type="text" name="address" id="main_address_input" value="<?= htmlspecialchars($employer['address'] ?? '') ?>" class="form-control" required placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố...">
                </div>
                <div class="form-group" style="margin-bottom: 0;">
                    <label class="form-label" style="font-size: 0.85rem; color: #334155; font-weight: 600; display: flex; align-items: center; gap: 0.35rem;">
                        <?= icon('location', '', 14) ?> <span>Link chỉ đường / vị trí Google Maps (Dán link công ty tự chọn trên Google Maps)</span>
                    </label>
                    <div style="display: flex; gap: 0.5rem; align-items: center;">
                        <input type="url" name="map_url" id="main_map_url_input" value="<?= htmlspecialchars($employer['map_url'] ?? '') ?>" class="form-control" placeholder="Dán link chia sẻ vị trí: https://maps.app.goo.gl/... hoặc https://maps.google.com/..." style="font-size: 0.88rem;">
                        <a href="https://www.google.com/maps" target="_blank" class="btn btn-outline btn-sm" style="white-space: nowrap; padding: 0.55rem 0.85rem; font-size: 0.82rem; font-weight: 700; color: #ffffff; border-color: #0d9488; background: #0d9488; display: inline-flex; align-items: center; gap: 0.3rem;" title="Mở Google Maps để tìm vị trí và copy link">
                            <?= icon('search', '', 13) ?> <span>Mở Google Maps</span>
                        </a>
                    </div>
                    <small style="color: #64748b; font-size: 0.8rem; margin-top: 0.35rem; display: flex; align-items: center; gap: 0.35rem;">
                        <?= icon('lightbulb', '', 13) ?> <em>Cách lấy link: Mở Google Maps &gt; Chọn đúng vị trí công ty của bạn &gt; Bấm nút <strong>Chia sẻ (Share)</strong> &gt; Chọn <strong>Sao chép đường liên kết</strong> và dán vào đây.</em>
                    </small>
                </div>
            </div>

            <!-- HỆ THỐNG CƠ sở & CHI NHÁNH KHÁC -->
            <div style="border-top: 2px dashed #e2e8f0; padding-top: 1.75rem; margin-top: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
                    <div>
                        <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--dark); margin-bottom: 0.2rem; display: flex; align-items: center; gap: 0.4rem;">
                            <?= icon('location', '', 18) ?> <span>danh sách Các cơ sở / Chi nhánh khác</span>
                        </h3>
                        <p style="font-size: 0.88rem; color: var(--slate-500); margin: 0;">
                            Lưu các địa điểm làm việc, cơ sở hoặc chi nhánh của doanh nghiệp kèm link Google Maps tự chọn
                        </p>
                    </div>
                    <button type="button" id="btnAddBranch" class="btn btn-outline btn-sm" style="border-color: #0d9488; color: #0d9488; font-weight: 700;">
                        + Thêm cơ sở Mới
                    </button>
                </div>

                <div id="branchesContainer" style="display: flex; flex-direction: column; gap: 1rem;">
                    <?php if (empty($branches)): ?>
                        <div id="noBranchAlert" style="text-align: center; padding: 1.5rem; background: #fafafa; border: 1px dashed #cbd5e1; border-radius: 8px; color: var(--slate-500); font-size: 0.9rem;">
                            Chưa có cơ sở chi nhánh phụ nào. Bấm nút <strong>"+ Thêm cơ sở Mới"</strong> để thêm địa điểm làm việc cho người lao động.
                        </div>
                    <?php else: ?>
                        <?php foreach ($branches as $idx => $b): ?>
                            <div class="branch-card" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px; padding: 1.15rem; box-shadow: 0 2px 6px rgba(0,0,0,0.03);">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.85rem;">
                                    <span style="font-weight: 700; color: #0f172a; font-size: 0.95rem; display: flex; align-items: center; gap: 0.35rem;">
                                        <?= icon('location', '', 14) ?> <span>Cơ sở / Chi nhánh #<?= $idx + 1 ?></span>
                                    </span>
                                    <button type="button" class="btn-remove-branch" style="background: #dc2626; color: #ffffff; border: 1px solid #dc2626; padding: 0.25rem 0.6rem; border-radius: 6px; font-size: 0.8rem; cursor: pointer; font-weight: 600;">
                                        Xóa
                                    </button>
                                </div>
                                <div class="form-row">
                                    <div class="form-group" style="margin-bottom: 0.75rem;">
                                        <label class="form-label" style="font-size: 0.85rem;">Tên cơ sở / Chi nhánh *</label>
                                        <input type="text" name="branches[<?= $idx ?>][name]" value="<?= htmlspecialchars($b['name'] ?? '') ?>" class="form-control" placeholder="VD: Cơ sở 2 - Thuận An" required>
                                    </div>
                                    <div class="form-group" style="margin-bottom: 0.75rem;">
                                        <label class="form-label" style="font-size: 0.85rem;">Hotline / SĐT cơ sở</label>
                                        <input type="text" name="branches[<?= $idx ?>][phone]" value="<?= htmlspecialchars($b['phone'] ?? '') ?>" class="form-control" placeholder="VD: 0274 3888 999">
                                    </div>
                                </div>
                                <div class="form-group" style="margin-bottom: 0.75rem;">
                                    <label class="form-label" style="font-size: 0.85rem;">địa chỉ chi tiết *</label>
                                    <input type="text" name="branches[<?= $idx ?>][address]" value="<?= htmlspecialchars($b['address'] ?? '') ?>" class="form-control branch-address" placeholder="Địa chỉ cơ sở này..." required>
                                </div>
                                <div class="form-group" style="margin-bottom: 0;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.25rem;">
                                        <label class="form-label" style="font-size: 0.82rem; color: #334155; font-weight: 600;">Link chia sẻ vị trí Google Maps</label>
                                        <?php if (!empty($b['map_url'])): ?>
                                            <a href="<?= htmlspecialchars($b['map_url']) ?>" target="_blank" style="font-size: 0.8rem; color: #0d9488; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 0.25rem;">
                                                <?= icon('location', '', 12) ?> <span>Xem vị trí</span>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                    <div style="display: flex; gap: 0.5rem; align-items: center;">
                                        <input type="url" name="branches[<?= $idx ?>][map_url]" value="<?= htmlspecialchars($b['map_url'] ?? '') ?>" class="form-control" placeholder="https://maps.app.goo.gl/... hoặc https://maps.google.com/..." style="font-size: 0.88rem;">
                                        <a href="https://www.google.com/maps" target="_blank" class="btn btn-outline btn-sm" style="white-space: nowrap; padding: 0.5rem 0.75rem; font-size: 0.8rem; color: #ffffff; border-color: #0d9488; background: #0d9488; display: inline-flex; align-items: center; gap: 0.25rem;" title="Mở Google Maps để lấy link">
                                            <?= icon('search', '', 12) ?> <span>Lấy link</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- CẤU HÌNH CÁC CA LÀM VIỆC MẪU CỦA DOANH NGHIỆP -->
            <div id="work_shifts_section" style="border-top: 2px dashed #e2e8f0; padding-top: 1.75rem; margin-top: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
                    <div>
                        <h3 style="font-size: 1.15rem; font-weight: 800; color: var(--dark); margin-bottom: 0.2rem; display: flex; align-items: center; gap: 0.4rem;">
                            <?= icon('clock', '', 18) ?> <span>hệ thống ca làm Việc mẫu của doanh nghiệp (Work shifts)</span>
                        </h3>
                        <p style="font-size: 0.88rem; color: var(--slate-500); margin: 0;">
                            Cài đặt sẵn các ca làm việc mẫu để khi đăng tin tuyển dụng chỉ cần nhấp chọn lại một chạm mà không cần gõ lại
                        </p>
                    </div>
                    <div style="display: flex; gap: 0.5rem; align-items: center; flex-wrap: wrap;">
                        <button type="button" id="btnInitDefaultShifts" class="btn btn-outline btn-sm" style="border-color: #6366f1; color: #4338ca; background: #eef2ff; font-weight: 600;">
                            <?= icon('zap', '', 12) ?> <span>Tạo mẫu ca chuẩn</span>
                        </button>
                        <button type="button" id="btnAddShift" class="btn btn-outline btn-sm" style="border-color: #0d9488; color: #0d9488; font-weight: 700;">
                            + Thêm ca làm Mới
                        </button>
                    </div>
                </div>

                <div id="shiftsContainer" style="display: flex; flex-direction: column; gap: 0.85rem;">
                    <?php if (empty($workShifts)): ?>
                        <div id="noShiftAlert" style="text-align: center; padding: 1.5rem; background: #fafafa; border: 1px dashed #cbd5e1; border-radius: 8px; color: var(--slate-500); font-size: 0.9rem;">
                            Chưa có ca làm việc mẫu nào. Bấm <strong>"+ Thêm ca làm Mới"</strong> hoặc <strong>"Tạo mẫu ca chuẩn"</strong> để thiết lập nhanh.
                        </div>
                    <?php else: ?>
                        <?php foreach ($workShifts as $sIdx => $s): ?>
                            <div class="shift-card" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px; padding: 1rem 1.15rem; box-shadow: 0 2px 6px rgba(0,0,0,0.03);">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.65rem;">
                                    <span style="font-weight: 700; color: #0f172a; font-size: 0.92rem; display: flex; align-items: center; gap: 0.35rem;">
                                        <?= icon('clock', '', 14) ?> <span>Ca làm việc #<?= $sIdx + 1 ?></span>
                                    </span>
                                    <button type="button" class="btn-remove-shift" style="background: #dc2626; color: #ffffff; border: 1px solid #dc2626; padding: 0.2rem 0.55rem; border-radius: 6px; font-size: 0.78rem; cursor: pointer; font-weight: 600;">
                                        Xóa
                                    </button>
                                </div>
                                <div class="form-row" style="margin-bottom: 0;">
                                    <div class="form-group" style="margin-bottom: 0.5rem; flex: 1;">
                                        <label class="form-label" style="font-size: 0.82rem; margin-bottom: 0.2rem;">Tên ca làm *</label>
                                        <input type="text" name="work_shifts[<?= $sIdx ?>][name]" value="<?= htmlspecialchars($s['name'] ?? '') ?>" class="form-control" placeholder="VD: Ca sáng / Hành chính" required style="font-size: 0.88rem;">
                                    </div>
                                    <?php $sHours = parseJobShiftHours($s['time'] ?? ''); ?>
                                    <div class="form-group" style="margin-bottom: 0.5rem; flex: 1.2;">
                                        <label class="form-label" style="font-size: 0.82rem; margin-bottom: 0.2rem;">Khung giờ (Bắt đầu - Kết thúc) *</label>
                                        <div style="display: grid; grid-template-columns: 1fr auto 1fr; gap: 0.4rem; align-items: center;">
                                            <input type="time" name="work_shifts[<?= $sIdx ?>][start_time]" value="<?= htmlspecialchars($sHours['start']) ?>" class="form-control" required style="font-size: 0.88rem; font-weight: 700; text-align: center; padding: 0.35rem 0.25rem; background: #fff; cursor: pointer;">
                                            <span style="font-size: 0.78rem; color: #64748b; font-weight: 700;">-</span>
                                            <input type="time" name="work_shifts[<?= $sIdx ?>][end_time]" value="<?= htmlspecialchars($sHours['end']) ?>" class="form-control" required style="font-size: 0.88rem; font-weight: 700; text-align: center; padding: 0.35rem 0.25rem; background: #fff; cursor: pointer;">
                                        </div>
                                    </div>
                                    <div class="form-group" style="margin-bottom: 0.5rem; flex: 1.3;">
                                        <label class="form-label" style="font-size: 0.82rem; margin-bottom: 0.2rem;">Ghi chú / Chế độ ca</label>
                                        <input type="text" name="work_shifts[<?= $sIdx ?>][description]" value="<?= htmlspecialchars($s['description'] ?? '') ?>" class="form-control" placeholder="VD: Nghỉ trưa 1 tiếng, bao cơm trưa" style="font-size: 0.88rem;">
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div style="margin-top: 2rem; border-top: 1px solid #e2e8f0; padding-top: 1.5rem;">
                <button type="submit" class="btn btn-primary" style="padding: 0.75rem 2rem; font-size: 1rem;">
                    Lưu thay đổi hồ sơ, cơ sở & ca làm Việc
                </button>
            </div>
        </form>
    </div>

    <!-- LỊCH SỬ THAY ĐỔI THÔNG TIN DOANH NGHIỆP (AUDIT TRAIL) - MẶC ĐỊNH THU GỌN -->
    <div class="card" style="margin-top: 2rem; box-shadow: 0 4px 16px rgba(0,0,0,0.04); border-radius: 14px; padding: 1.15rem 1.4rem; transition: all 0.2s ease; border: 1px solid #e2e8f0;">
        <div id="employerHistoryHeader" style="display: flex; justify-content: space-between; align-items: center; cursor: pointer; user-select: none; gap: 0.75rem;" onclick="toggleEmployerHistory()">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
                <div style="width: 38px; height: 38px; border-radius: 10px; background: #f0fdfa; border: 1px solid #ccfbf1; color: #0d9488; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <?= icon('clock', '', 20) ?>
                </div>
                <div>
                    <h3 style="font-size: 1.05rem; font-weight: 800; color: #0f172a; margin: 0; display: flex; align-items: center; gap: 0.45rem; flex-wrap: wrap;">
                        <span>lịch sử Thay đổi thông tin doanh nghiệp</span>
                        <span class="badge badge-primary" style="font-size: 0.75rem; padding: 0.15rem 0.55rem; border-radius: 20px; font-weight: 700;">
                            <?= count($historyLogs ?? []) ?>
                        </span>
                    </h3>
                    <p style="font-size: 0.82rem; color: #64748b; margin: 0.2rem 0 0 0;">
                        Nhật ký ghi nhận mọi thay đổi thông tin công ty (doanh nghiệp tự cập nhật hoặc do Quản trị viên can thiệp).
                    </p>
                </div>
            </div>

            <div style="display: flex; align-items: center; gap: 0.65rem; flex-shrink: 0;">
                <span class="badge badge-outline" style="font-size: 0.75rem; font-weight: 600;">Lưu vết tự động</span>
                <span class="btn btn-sm btn-outline" style="pointer-events: none; font-size: 0.8rem; font-weight: 700; padding: 0.35rem 0.75rem; border-radius: 20px; color: #0d9488; border-color: #99f6e4; background: #f0fdfa; display: inline-flex; align-items: center; gap: 0.35rem;">
                    <span id="toggleEmpHistoryText">Mở rộng xem</span>
                    <svg id="toggleEmpHistoryChevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transition: transform 0.25s ease;">
                        <polyline points="6 9 12 15 18 9"></polyline>
                    </svg>
                </span>
            </div>
        </div>

        <!-- NỘI DUNG BẢNG LỊCH SỬ (MẶC ĐỊNH THU GỌN, CHỈ HIỆN KHI BẤM MỞ) -->
        <div id="employerHistoryContent" style="display: none; margin-top: 1.15rem; border-top: 1px dashed #e2e8f0; padding-top: 1rem;">
            <?= class_exists('ProfileHistoryService') ? ProfileHistoryService::renderHistoryTableHtml($historyLogs ?? [], 'Chưa có lịch sử thay đổi thông tin doanh nghiệp nào.') : '' ?>
        </div>
    </div>

    <script>
    function toggleEmployerHistory() {
        const content = document.getElementById('employerHistoryContent');
        const text = document.getElementById('toggleEmpHistoryText');
        const chevron = document.getElementById('toggleEmpHistoryChevron');
        if (!content) return;

        const isHidden = content.style.display === 'none';
        if (isHidden) {
            content.style.display = 'block';
            if (text) text.innerText = 'Thu gọn lại';
            if (chevron) chevron.style.transform = 'rotate(180deg)';
        } else {
            content.style.display = 'none';
            if (text) text.innerText = 'Mở rộng xem';
            if (chevron) chevron.style.transform = 'rotate(0deg)';
        }
    }
    </script>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('branchesContainer');
    const btnAdd = document.getElementById('btnAddBranch');
    const noBranchAlert = document.getElementById('noBranchAlert');

    let branchCount = container.querySelectorAll('.branch-card').length;

    function checkEmptyAlert() {
        const cards = container.querySelectorAll('.branch-card');
        if (cards.length === 0) {
            if (!document.getElementById('noBranchAlert')) {
                const alertDiv = document.createElement('div');
                alertDiv.id = 'noBranchAlert';
                alertDiv.style.cssText = 'text-align: center; padding: 1.5rem; background: #fafafa; border: 1px dashed #cbd5e1; border-radius: 8px; color: var(--slate-500); font-size: 0.9rem;';
                alertDiv.innerHTML = 'Chưa có cơ sở chi nhánh phụ nào. Bấm nút <strong>"+ Thêm cơ sở Mới"</strong> để thêm địa điểm làm việc cho người lao động.';
                container.appendChild(alertDiv);
            }
        } else {
            const alertElem = document.getElementById('noBranchAlert');
            if (alertElem) alertElem.remove();
        }
    }

    btnAdd.addEventListener('click', function() {
        const alertElem = document.getElementById('noBranchAlert');
        if (alertElem) alertElem.remove();

        const index = Date.now();
        const displayIndex = container.querySelectorAll('.branch-card').length + 1;

        const card = document.createElement('div');
        card.className = 'branch-card';
        card.style.cssText = 'background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px; padding: 1.15rem; box-shadow: 0 2px 6px rgba(0,0,0,0.03); animation: fadeIn 0.3s ease;';
        card.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.85rem;">
                <span style="font-weight: 700; color: #0f172a; font-size: 0.95rem; display: flex; align-items: center; gap: 0.35rem;">
                    <?= icon('location', '', 14) ?> <span>Cơ sở / Chi nhánh mới #\${displayIndex}</span>
                </span>
                <button type="button" class="btn-remove-branch" style="background: #dc2626; color: #ffffff; border: 1px solid #dc2626; padding: 0.25rem 0.6rem; border-radius: 6px; font-size: 0.8rem; cursor: pointer; font-weight: 600;">
                    Xóa
                </button>
            </div>
            <div class="form-row">
                <div class="form-group" style="margin-bottom: 0.75rem;">
                    <label class="form-label" style="font-size: 0.85rem;">Tên cơ sở / Chi nhánh *</label>
                    <input type="text" name="branches[\${index}][name]" class="form-control" placeholder="VD: Cơ sở 2 - Thuận An" required>
                </div>
                <div class="form-group" style="margin-bottom: 0.75rem;">
                    <label class="form-label" style="font-size: 0.85rem;">Hotline / SĐT cơ sở</label>
                    <input type="text" name="branches[\${index}][phone]" class="form-control" placeholder="VD: 0274 3888 999">
                </div>
            </div>
            <div class="form-group" style="margin-bottom: 0.75rem;">
                <label class="form-label" style="font-size: 0.85rem;">địa chỉ chi tiết *</label>
                <input type="text" name="branches[\${index}][address]" class="form-control branch-address" placeholder="Địa chỉ cơ sở này..." required>
            </div>
            <div class="form-group" style="margin-bottom: 0;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.25rem;">
                    <label class="form-label" style="font-size: 0.82rem; color: #334155; font-weight: 600;">Link chia sẻ vị trí Google Maps</label>
                </div>
                <div style="display: flex; gap: 0.5rem; align-items: center;">
                    <input type="url" name="branches[\${index}][map_url]" class="form-control" placeholder="https://maps.app.goo.gl/... hoặc https://maps.google.com/..." style="font-size: 0.88rem;">
                    <a href="https://www.google.com/maps" target="_blank" class="btn btn-outline btn-sm" style="white-space: nowrap; padding: 0.5rem 0.75rem; font-size: 0.8rem; color: #ffffff; border-color: #0d9488; background: #0d9488; display: inline-flex; align-items: center; gap: 0.25rem;" title="Mở Google Maps để lấy link">
                        <?= icon('search', '', 12) ?> <span>Lấy link</span>
                    </a>
                </div>
            </div>
        `;

        container.appendChild(card);
        card.querySelector('input[type="text"]').focus();
    });

    container.addEventListener('click', function(e) {
        const btnRemove = e.target.closest('.btn-remove-branch');
        if (btnRemove) {
            const card = btnRemove.closest('.branch-card');
            if (card) {
                card.remove();
                checkEmptyAlert();
            }
        }
    });

    // === CẤU HÌNH CA LÀM VIỆC MẪU (WORK SHIFTS) ===
    const shiftsContainer = document.getElementById('shiftsContainer');
    const btnAddShift = document.getElementById('btnAddShift');
    const btnInitDefaultShifts = document.getElementById('btnInitDefaultShifts');

    function checkEmptyShiftsAlert() {
        if (!shiftsContainer) return;
        const cards = shiftsContainer.querySelectorAll('.shift-card');
        if (cards.length === 0) {
            if (!document.getElementById('noShiftAlert')) {
                const alertDiv = document.createElement('div');
                alertDiv.id = 'noShiftAlert';
                alertDiv.style.cssText = 'text-align: center; padding: 1.5rem; background: #fafafa; border: 1px dashed #cbd5e1; border-radius: 8px; color: var(--slate-500); font-size: 0.9rem;';
                alertDiv.innerHTML = 'Chưa có ca làm việc mẫu nào. Bấm <strong>"+ Thêm ca làm Mới"</strong> hoặc <strong>"Tạo mẫu ca chuẩn"</strong> để thiết lập nhanh.';
                shiftsContainer.appendChild(alertDiv);
            }
        } else {
            const alertElem = document.getElementById('noShiftAlert');
            if (alertElem) alertElem.remove();
        }
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function parseShiftTime(timeStr) {
        let start = '08:00';
        let end = '17:00';
        if (!timeStr) return { start, end };
        const matches = [...timeStr.matchAll(/(\d{1,2})(?:[h:H:](\d{1,2})?)?/g)];
        if (matches.length > 0 && matches[0][1]) {
            const h = String(matches[0][1]).padStart(2, '0');
            const m = matches[0][2] ? String(matches[0][2]).padStart(2, '0') : '00';
            start = `${h}:${m}`;
        }
        if (matches.length > 1 && matches[1][1]) {
            const h = String(matches[1][1]).padStart(2, '0');
            const m = matches[1][2] ? String(matches[1][2]).padStart(2, '0') : '00';
            end = `${h}:${m}`;
        }
        return { start, end };
    }

    function createShiftCard(name = '', time = '', desc = '') {
        const alertElem = document.getElementById('noShiftAlert');
        if (alertElem) alertElem.remove();

        const index = Date.now() + Math.floor(Math.random() * 1000);
        const displayIndex = shiftsContainer.querySelectorAll('.shift-card').length + 1;
        const parsed = parseShiftTime(time);

        const card = document.createElement('div');
        card.className = 'shift-card';
        card.style.cssText = 'background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px; padding: 1rem 1.15rem; box-shadow: 0 2px 6px rgba(0,0,0,0.03); animation: fadeIn 0.3s ease;';
        card.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.65rem;">
                <span style="font-weight: 700; color: #0f172a; font-size: 0.92rem; display: flex; align-items: center; gap: 0.35rem;">
                    <?= icon('clock', '', 14) ?> <span>Ca làm việc #${displayIndex}</span>
                </span>
                <button type="button" class="btn-remove-shift" style="background: #dc2626; color: #ffffff; border: 1px solid #dc2626; padding: 0.2rem 0.55rem; border-radius: 6px; font-size: 0.78rem; cursor: pointer; font-weight: 600;">
                    Xóa
                </button>
            </div>
            <div class="form-row" style="margin-bottom: 0;">
                <div class="form-group" style="margin-bottom: 0.5rem; flex: 1;">
                    <label class="form-label" style="font-size: 0.82rem; margin-bottom: 0.2rem;">Tên ca làm *</label>
                    <input type="text" name="work_shifts[${index}][name]" value="${escapeHtml(name)}" class="form-control" placeholder="VD: Ca sáng / Hành chính" required style="font-size: 0.88rem;">
                </div>
                <div class="form-group" style="margin-bottom: 0.5rem; flex: 1.2;">
                    <label class="form-label" style="font-size: 0.82rem; margin-bottom: 0.2rem;">Khung giờ (Bắt đầu - Kết thúc) *</label>
                    <div style="display: grid; grid-template-columns: 1fr auto 1fr; gap: 0.4rem; align-items: center;">
                        <input type="time" name="work_shifts[${index}][start_time]" value="${parsed.start}" class="form-control" required style="font-size: 0.88rem; font-weight: 700; text-align: center; padding: 0.35rem 0.25rem; background: #fff; cursor: pointer;">
                        <span style="font-size: 0.78rem; color: #64748b; font-weight: 700;">-</span>
                        <input type="time" name="work_shifts[${index}][end_time]" value="${parsed.end}" class="form-control" required style="font-size: 0.88rem; font-weight: 700; text-align: center; padding: 0.35rem 0.25rem; background: #fff; cursor: pointer;">
                    </div>
                </div>
                <div class="form-group" style="margin-bottom: 0.5rem; flex: 1.3;">
                    <label class="form-label" style="font-size: 0.82rem; margin-bottom: 0.2rem;">Ghi chú / Chế độ ca</label>
                    <input type="text" name="work_shifts[${index}][description]" value="${escapeHtml(desc)}" class="form-control" placeholder="VD: Nghỉ trưa 1 tiếng, bao cơm trưa" style="font-size: 0.88rem;">
                </div>
            </div>
        `;

        shiftsContainer.appendChild(card);
        return card;
    }

    if (btnAddShift) {
        btnAddShift.addEventListener('click', function() {
            const card = createShiftCard();
            const firstInput = card.querySelector('input[type="text"]');
            if (firstInput) firstInput.focus();
        });
    }

    if (shiftsContainer) {
        shiftsContainer.addEventListener('click', function(e) {
            const btnRemove = e.target.closest('.btn-remove-shift');
            if (btnRemove) {
                const card = btnRemove.closest('.shift-card');
                if (card) {
                    card.remove();
                    checkEmptyShiftsAlert();
                }
            }
        });
    }

    if (btnInitDefaultShifts) {
        btnInitDefaultShifts.addEventListener('click', function() {
            const defaultPresets = [
                { name: 'Giờ hành chính', time: '8h00 - 17h00', desc: 'Nghỉ trưa 1 tiếng, Thứ 2 - Thứ 6' },
                { name: 'Ca sáng', time: '6h00 - 14h00', desc: 'Bao cơm giữa ca' },
                { name: 'Ca chiều', time: '14h00 - 22h00', desc: 'Phụ cấp ca chiều' },
                { name: 'Ca tối / Bán thời gian', time: '18h00 - 22h00', desc: 'Phù hợp sinh viên làm thêm' },
                { name: 'Ca đêm', time: '22h00 - 6h00', desc: 'Phụ cấp làm đêm 30%' }
            ];

            const existingCards = shiftsContainer.querySelectorAll('.shift-card');
            if (existingCards.length > 0) {
                if (!confirm('Bạn đã có ca làm việc trong danh sách. Bạn có muốn thêm các ca mẫu chuẩn phổ biến vào tiếp theo không?')) {
                    return;
                }
            }

            defaultPresets.forEach(preset => {
                createShiftCard(preset.name, preset.time, preset.desc);
            });
        });
    }
});

function previewEmployerAvatar(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('employer_avatar_img');
            if (preview) preview.src = e.target.result;
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/../layouts/user_layout.php';
?>
