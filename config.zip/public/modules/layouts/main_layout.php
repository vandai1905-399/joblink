<?php
// 1. KIỂM TRA CHẾ ĐỘ NHÚNG TAB (EMBEDDED VIEWPORT)
$isEmbedded = (isset($_GET['embedded']) && $_GET['embedded'] == '1')
    || (isset($_SERVER['HTTP_SEC_FETCH_DEST']) && $_SERVER['HTTP_SEC_FETCH_DEST'] === 'iframe');
if ($isEmbedded):
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'JobLink') ?></title>
    <link rel="icon" type="image/png" href="<?= getSystemLogo() ?>">
    <link rel="shortcut icon" type="image/png" href="<?= getSystemLogo() ?>">
    <link rel="apple-touch-icon" href="<?= getSystemLogo() ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= asset('css/style.css?v=' . (file_exists(__DIR__ . '/../../css/style.css') ? filemtime(__DIR__ . '/../../css/style.css') : time())) ?>">
    <link rel="stylesheet" href="<?= asset('css/dialog.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/ai_chatbox.css?v=' . (file_exists(__DIR__ . '/../../css/ai_chatbox.css') ? filemtime(__DIR__ . '/../../css/ai_chatbox.css') : time())) ?>">
    <link rel="stylesheet" href="<?= asset('css/mobile.css') ?>">
    <?php if (!empty($extraCss)): ?>
        <?php foreach ((array)$extraCss as $cssFile): ?>
            <?php
                $cssFsPath = __DIR__ . '/../../' . ltrim($cssFile, '/');
                $cssVer = file_exists($cssFsPath) ? filemtime($cssFsPath) : time();
            ?>
            <link rel="stylesheet" href="<?= asset($cssFile . '?v=' . $cssVer) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
    <script>window.APP_URL = '<?= url('') ?>';</script>
</head>
<body style="background: #ffffff; margin: 0; padding: 0;">
    <div class="embedded-content-wrapper">
        <?= $content ?? '' ?>
    </div>
    <script src="<?= asset('js/dialog.js') ?>"></script>
    <script src="<?= asset('js/app.js?v=' . (file_exists(__DIR__ . '/../../js/app.js') ? filemtime(__DIR__ . '/../../js/app.js') : time())) ?>"></script>
    <?php if (!empty($extraJs)): ?>
        <?php foreach ((array)$extraJs as $jsFile): ?>
            <?php
                $jsFsPath = __DIR__ . '/../../' . ltrim($jsFile, '/');
                $jsVer = file_exists($jsFsPath) ? filemtime($jsFsPath) : time();
            ?>
            <script src="<?= asset($jsFile . '?v=' . $jsVer) ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    <?= class_exists('DialogHelper') ? DialogHelper::renderFlashScript() : '' ?>
    <script>
        // 1. Chuyển hướng mọi liên kết nội bộ thành mở tab trong Dashboard MasterWorkspace
        document.addEventListener('click', function(e) {
            var link = e.target.closest('a');
            if (link) {
                var href = link.getAttribute('href');
                if (!href || href.startsWith('javascript:') || href.startsWith('#') || href.includes('logout') || link.hasAttribute('download')) return;

                try {
                    var targetUrl = new URL(link.href, window.location.origin);
                    // Nếu là liên kết ngoài (Google Maps, website ngoài...) -> Cho phép mở bình thường / target="_blank"
                    if (targetUrl.origin !== window.location.origin) {
                        return;
                    }

                    // Nếu là liên kết nội bộ hệ thống và đang nằm trong iframe con của MasterWorkspace
                    if (window.parent && window.parent !== window) {
                        e.preventDefault();
                        link.removeAttribute('target');
                        var title = link.getAttribute('data-title') || link.innerText.trim() || 'chi tiết';
                        title = title.replace(/[→←&rarr;&larr;]/g, '').trim();
                        if (title.length > 25) title = title.substring(0, 22) + '...';

                        if (window.parent.MasterWorkspace && typeof window.parent.MasterWorkspace.openTab === 'function') {
                            window.parent.MasterWorkspace.openTab(link.href, title);
                            return;
                        } else {
                            window.parent.postMessage({
                                action: 'openTab',
                                url: link.href,
                                title: title
                            }, '*');
                            return;
                        }
                    }
                } catch(err) {}
            }
        });

        // 2. Tự động thêm tham số embedded=1 cho mọi form POST/GET bên trong iframe
        document.addEventListener('submit', function(e) {
            var form = e.target;
            if (!form.querySelector('input[name="embedded"]')) {
                var hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'embedded';
                hidden.value = '1';
                form.appendChild(hidden);
            }
        });

        // 3. Bắt phím tắt bên trong iframe:
        // - F5 / Ctrl+R: Chỉ tải lại riêng iframe này
        // - Ctrl+W / Alt+W / Ctrl+Q / Ctrl+F4: Tắt tab con hiện hành trong Dashboard
        document.addEventListener('keydown', function(e) {
            if (e.key === 'F5' || (e.ctrlKey && e.key.toLowerCase() === 'r')) {
                e.preventDefault();
                window.location.reload();
                return;
            }

            var isCloseTab = (
                ((e.ctrlKey || e.metaKey) && (e.key === 'w' || e.key === 'W' || e.code === 'KeyW')) ||
                (e.altKey && (e.key === 'w' || e.key === 'W' || e.code === 'KeyW')) ||
                ((e.ctrlKey || e.metaKey) && (e.key === 'q' || e.key === 'Q' || e.code === 'KeyQ')) ||
                (e.ctrlKey && e.key === 'F4')
            );

            if (isCloseTab) {
                e.preventDefault();
                e.stopPropagation();
                if (window.parent && window.parent !== window) {
                    try {
                        if (window.parent.MasterWorkspace && typeof window.parent.MasterWorkspace.closeActiveTab === 'function') {
                            window.parent.MasterWorkspace.closeActiveTab();
                        } else {
                            window.parent.postMessage({ action: 'closeActiveTab' }, '*');
                        }
                    } catch (err) {
                        window.parent.postMessage({ action: 'closeActiveTab' }, '*');
                    }
                }
            }
        });
    </script>
</body>
</html>
<?php
exit;
endif;

// TỰ ĐỘNG CHUYỂN HƯỚNG CÁC TRANG NỘI DUNG VỀ KHUNG DASHBOARD KHI NGƯỜI DÙNG ĐÃ ĐĂNG NHẬP
$userSession = $_SESSION['user'] ?? [];
if (!empty($userSession['role_code'])) {
    $uRole = $userSession['role_code'];
    $targetDashUrl = url('/seeker/dashboard');
    $targetDashPath = '/seeker/dashboard';
    if ($uRole === 'EMPLOYER_ADMIN') {
        $targetDashUrl = url('/employer/dashboard');
        $targetDashPath = '/employer/dashboard';
    } elseif ($uRole === 'INTERMEDIARY') {
        $targetDashUrl = url('/intermediary/dashboard');
        $targetDashPath = '/intermediary/dashboard';
    } elseif (in_array($uRole, ['SUPER_ADMIN', 'SUB_ADMIN', 'CSKH_STAFF'])) {
        $targetDashUrl = url('/admin/dashboard');
        $targetDashPath = '/admin/dashboard';
    }

    $reqUri = $_SERVER['REQUEST_URI'] ?? '/';
    $reqPath = parse_url($reqUri, PHP_URL_PATH) ?? '/';
    $scriptDir = dirname($_SERVER['SCRIPT_NAME'] ?? '');
    $cleanPath = str_replace('\\', '/', $scriptDir);
    if ($cleanPath !== '/' && $cleanPath !== '' && strpos($reqPath, $cleanPath) === 0) {
        $reqPath = substr($reqPath, strlen($cleanPath));
    }
    $reqPath = preg_replace('#^/(Joblink|public|Joblink/public)#i', '', $reqPath);
    $cleanReq = '/' . trim($reqPath, '/');

    // Chuyển hướng các trang nghiệp vụ như /employers, /jobs, /auth/change-password về khung dashboard
    $shouldEmbedInDashboard = (
        strpos($cleanReq, '/employers') === 0 ||
        strpos($cleanReq, '/jobs') === 0 ||
        strpos($cleanReq, '/auth/change-password') === 0 ||
        strpos($cleanReq, '/reviews') === 0
    );

    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $cleanReq !== $targetDashPath && $cleanReq !== '/' && $cleanReq !== '' && $shouldEmbedInDashboard) {
        header('Location: ' . $targetDashUrl . '?open=' . urlencode($reqUri));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'JobLink - Cổng kết nối việc làm') ?></title>
    <link rel="icon" type="image/png" href="<?= getSystemLogo() ?>">
    <link rel="shortcut icon" type="image/png" href="<?= getSystemLogo() ?>">
    <link rel="apple-touch-icon" href="<?= getSystemLogo() ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= asset('css/style.css?v=' . (file_exists(__DIR__ . '/../../css/style.css') ? filemtime(__DIR__ . '/../../css/style.css') : time())) ?>">
    <link rel="stylesheet" href="<?= asset('css/dialog.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/ai_chatbox.css?v=' . (file_exists(__DIR__ . '/../../css/ai_chatbox.css') ? filemtime(__DIR__ . '/../../css/ai_chatbox.css') : time())) ?>">
    <link rel="stylesheet" href="<?= asset('css/mobile.css') ?>">
    <?php if (!empty($extraCss)): ?>
        <?php foreach ((array)$extraCss as $cssFile): ?>
            <?php
                $cssFsPath = __DIR__ . '/../../' . ltrim($cssFile, '/');
                $cssVer = file_exists($cssFsPath) ? filemtime($cssFsPath) : time();
            ?>
            <link rel="stylesheet" href="<?= asset($cssFile . '?v=' . $cssVer) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
    <script>window.APP_URL = '<?= url('') ?>';</script>
    <script>
        // Tự động nhận diện nếu chạy trong iframe để tránh lồng layout 2 lần
        if (window.self !== window.top && !window.location.search.includes('embedded=1')) {
            var sep = window.location.href.indexOf('?') !== -1 ? '&' : '?';
            window.location.replace(window.location.href + sep + 'embedded=1');
        }
    </script>
</head>
<body class="<?= (isset($_SESSION['user']) && ($_SESSION['user']['role_code'] ?? '') === 'JOB_SEEKER') ? 'role-job-seeker' : '' ?>" style="min-height: 100vh; display: flex; flex-direction: column;">
    <?php require_once __DIR__ . '/mobile_nav.php'; ?>
    <header class="navbar">
        <div class="nav-container">
            <?php
                $userRole = $_SESSION['user']['role_code'] ?? '';
                $dashUrl = url('/');
                if ($userRole === 'JOB_SEEKER') $dashUrl = url('/seeker/dashboard');
                elseif ($userRole === 'EMPLOYER_ADMIN') $dashUrl = url('/employer/dashboard');
                elseif ($userRole === 'INTERMEDIARY') $dashUrl = url('/intermediary/dashboard');
                elseif (in_array($userRole, ['SUPER_ADMIN', 'SUB_ADMIN', 'CSKH_STAFF'])) $dashUrl = url('/admin/dashboard');
            ?>
            <a href="<?= isset($_SESSION['user']) ? $dashUrl : url('/') ?>" class="logo">
                <img src="<?= getSystemLogo() ?>" alt="JobLink Logo" class="brand-logo-img" style="width: 26px; height: 26px; object-fit: contain; vertical-align: middle; margin-right: 6px;">
                <span>JobLink</span>
                <span class="logo-badge">Kết nối việc làm</span>
            </a>
            <ul class="nav-links">
                <?php if (!isset($_SESSION['user'])): ?>
                    <li><a href="<?= url('/') ?>" class="nav-link">Trang chủ</a></li>
                <?php endif; ?>
                <li><a href="<?= url('/jobs') ?>" class="nav-link">Tìm việc làm</a></li>
                <li><a href="<?= url('/employers') ?>" class="nav-link">Nhà tuyển dụng</a></li>
                <li><a href="<?= url('/about') ?>" class="nav-link">Giới thiệu</a></li>
            </ul>
            <div class="nav-actions">
                <?php if (isset($_SESSION['user'])): ?>
                    <?php
                        $uDisplayName = $_SESSION['user']['display_name'] ?? $_SESSION['user']['username'];
                        $uAvatar = getAvatarUrl($_SESSION['user']['avatar_url'] ?? '', $userRole);
                        $roleNameText = ($userRole === 'EMPLOYER_ADMIN') ? 'Nhà tuyển dụng' : (($userRole === 'INTERMEDIARY') ? 'Người trung gian' : (($userRole === 'JOB_SEEKER') ? 'Người lao động' : 'Quản trị viên'));
                    ?>
                    <!-- Cụm icon tin nhắn & Thông báo -->
                    <?= renderHeaderIcons($_SESSION['user'] ?? null) ?>

                    <!-- Nút avatar tròn phong cách facebook -->
                    <div class="user-dropdown-container">
                        <button type="button" class="user-dropdown-trigger fb-avatar-trigger" title="<?= htmlspecialchars($uDisplayName) ?>">
                            <img src="<?= htmlspecialchars($uAvatar) ?>" alt="avatar" class="fb-nav-avatar" onerror="this.src='<?= getSystemLogo() ?>'">
                            <span class="fb-chevron-badge"><?= icon('chevron_down', '', 9) ?></span>
                        </button>

                        <div class="user-dropdown-menu fb-dropdown-menu">
                            <!-- 1. HỘP PROFILE TRANG CÁ NHÂN / BẢNG ĐIỀU KHIỂN (FB STYLE) -->
                            <a href="<?= $dashUrl ?>" class="fb-profile-card-box">
                                <div class="fb-card-user">
                                    <img src="<?= htmlspecialchars($uAvatar) ?>" alt="avatar" class="fb-card-avatar" onerror="this.src='<?= getSystemLogo() ?>'">
                                    <div class="fb-card-meta">
                                        <div class="fb-card-name"><?= htmlspecialchars($uDisplayName) ?></div>
                                        <div class="fb-card-role"><?= htmlspecialchars($roleNameText) ?> • @<?= htmlspecialchars($_SESSION['user']['username']) ?></div>
                                    </div>
                                </div>
                                <div class="fb-view-profile-btn">
                                    <?= icon('user', '', 15) ?>
                                    <span>Xem bảng điều khiển & trang cá nhân</span>
                                </div>
                            </a>

                            <div class="fb-divider"></div>

                            <!-- 2. DANH SÁCH MENU ĐIỀU HƯỚNG FB STYLE -->
                            <div class="fb-menu-list">
                                <?php if ($userRole === 'JOB_SEEKER'): ?>
                                    <a href="<?= url('/seeker/profile') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('user', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Hồ sơ năng lực & Điểm uy tín</div>
                                            <div class="fb-item-desc">Kỹ năng, vị trí & Trust score</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                    <a href="<?= url('/seeker/settings') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('settings', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Cài đặt & Cam kết việc làm</div>
                                            <div class="fb-item-desc">Ký cam kết không bùng ca & Gmail</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                <?php elseif ($userRole === 'EMPLOYER_ADMIN'): ?>
                                    <a href="<?= url('/employer/company-profile') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('building', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Hồ sơ doanh nghiệp & GPKD</div>
                                            <div class="fb-item-desc">Thông tin công ty và người đại diện</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                    <a href="<?= url('/employer/settings?tab=cert') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('certificate', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Chữ ký số & Hợp đồng</div>
                                            <div class="fb-item-desc">Xác thực CA và hợp đồng điện tử</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                    <a href="<?= url('/employer/settings?tab=auth') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('handshake', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Ủy quyền Người trung gian</div>
                                            <div class="fb-item-desc">Văn bản ủy quyền tuyển dụng pháp lý</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                    <a href="<?= url('/employer/settings?tab=mail') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('mail', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Cài đặt & Thông báo Gmail</div>
                                            <div class="fb-item-desc">Đồng bộ email nhận hồ sơ người lao động</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                <?php elseif ($userRole === 'INTERMEDIARY'): ?>
                                    <a href="<?= url('/intermediary/settings?tab=contracts') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('handshake', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Hợp đồng & Văn bản ủy quyền</div>
                                            <div class="fb-item-desc">Quản lý giấy ủy quyền tuyển dụng</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                    <a href="<?= url('/intermediary/settings?tab=mail') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('mail', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Cài đặt & Thông báo Gmail</div>
                                            <div class="fb-item-desc">Cấu hình nhận email ứng tuyển</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                <?php elseif (in_array($userRole, ['SUPER_ADMIN', 'SUB_ADMIN', 'CSKH_STAFF'])): ?>
                                    <a href="<?= url('/admin/settings') ?>" class="fb-menu-item">
                                        <div class="fb-item-icon"><?= icon('settings', '', 17) ?></div>
                                        <div class="fb-item-content">
                                            <div class="fb-item-title">Cài đặt hệ thống & Root CA</div>
                                            <div class="fb-item-desc">Cấu hình máy chủ, Gmail & Chữ ký số</div>
                                        </div>
                                        <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                    </a>
                                <?php endif; ?>

                                <a href="<?= url('/auth/change-password') ?>" class="fb-menu-item">
                                    <div class="fb-item-icon"><?= icon('lock', '', 17) ?></div>
                                    <div class="fb-item-content">
                                        <div class="fb-item-title">Đổi mật khẩu & Bảo mật</div>
                                    </div>
                                    <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                </a>

                                <a href="<?= url('/auth/logout') ?>" class="fb-menu-item fb-item-danger">
                                    <div class="fb-item-icon"><?= icon('logout', '', 17) ?></div>
                                    <div class="fb-item-content">
                                        <div class="fb-item-title">Đăng xuất</div>
                                    </div>
                                    <div class="fb-item-arrow"><?= icon('chevron_right', '', 14) ?></div>
                                </a>
                            </div>

                            <!-- 3. FOOTER -->
                            <div class="fb-dropdown-footer">
                                Quyền riêng tư · Điều khoản · JobLink © <?= date('Y') ?>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= url('/auth/login') ?>" class="btn btn-outline btn-sm">Đăng nhập</a>
                    <a href="<?= url('/auth/register') ?>" class="btn btn-primary btn-sm">Đăng ký</a>
                <?php endif; ?>

            </div>
        </div>
    </header>

    <main style="flex: 1 0 auto;">
        <?= $content ?? '' ?>
    </main>

    <?php
        // FOOTER CHỈ HIỂN THỊ DUY NHẤT TẠI TRANG CHỦ (LANDING PAGE)
        // Các trang chức năng (tìm việc, đăng nhập, đăng ký, tra cứu...) và người dùng đã đăng nhập đều ẩn footer
        $isHomeLanding = false;
        if (!empty($isHomePage) || !empty($showFooter)) {
            $isHomeLanding = true;
        } else {
            $reqUri = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
            $appBase = trim(parse_url(url('/'), PHP_URL_PATH) ?? '', '/');
            if ($appBase && strpos($reqUri, $appBase) === 0) {
                $reqUri = trim(substr($reqUri, strlen($appBase)), '/');
            }
            if ($reqUri === '' || $reqUri === 'home') {
                $isHomeLanding = true;
            }
        }
        $renderFooter = $isHomeLanding && empty($isEmbedded) && !isset($_SESSION['user']);
    ?>

    <?php if ($renderFooter): ?>
    <footer class="footer">
        <div class="footer-grid">
            <div>
                <a href="<?= url('/') ?>" class="logo" style="color:#fff; margin-bottom: 1rem; display: inline-flex;">
                    JobLink
                </a>
                <p style="font-size: 0.9rem; line-height: 1.6;">
                    Nền tảng kết nối người lao động và nhà tuyển dụng trực tiếp, minh bạch với hệ thống đánh giá ca làm việc 2 chiều đầu tiên tại Bình Dương & toàn quốc.
                </p>
            </div>
            <div>
                <h4 class="footer-title">Dành cho người lao động</h4>
                <ul class="footer-links">
                    <li><a href="<?= url('/jobs') ?>">Tìm việc theo ca</a></li>
                    <li><a href="<?= url('/jobs?employment_type=part_time') ?>">Việc làm Part-time</a></li>
                    <li><a href="<?= url('/jobs?employment_type=full_time') ?>">Việc làm Full-time</a></li>
                    <li><a href="<?= url('/employers') ?>">Tra cứu Doanh nghiệp</a></li>
                </ul>
            </div>
            <div>
                <h4 class="footer-title">Nhà tuyển dụng</h4>
                <ul class="footer-links">
                    <li><a href="<?= url('/employer/jobs/create') ?>">Đăng tin tuyển dụng</a></li>
                    <li><a href="<?= url('/employer/dashboard') ?>">Quản lý người lao động</a></li>
                    <li><a href="<?= url('/employer/meetings') ?>">Lên lịch phỏng vấn</a></li>
                    <li><a href="<?= url('/about') ?>">Quy trình xác minh GPKD</a></li>
                </ul>
            </div>
            <div>
                <h4 class="footer-title">hệ thống</h4>
                <ul class="footer-links">
                    <li><a href="<?= url('/about') ?>">Về chúng tôi</a></li>
                    <li><a href="<?= url('/admin/dashboard') ?>">Cổng quản trị</a></li>
                    <li><a href="mailto:admin.dai@joblink.io.vn">Liên hệ: admin.dai@joblink.io.vn</a></li>
                    <li><a href="tel:0793497434">Hotline: 0793 497 434</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?= date('Y') ?> JobLink.io.vn<p>
        </div>
    </footer>
    <?php endif; ?>
    <script src="<?= asset('js/dialog.js') ?>"></script>
    <script src="<?= asset('js/app.js?v=' . (file_exists(__DIR__ . '/../../js/app.js') ? filemtime(__DIR__ . '/../../js/app.js') : time())) ?>"></script>
    <script>
        window.APP_URL = '<?= url('') ?>';
        window.JOBY_GREETING = <?= json_encode(getAiGreeting(), JSON_UNESCAPED_UNICODE) ?>;
        window.JOBY_BUBBLE_DATA = <?= json_encode(getAiProactiveSummary(), JSON_UNESCAPED_UNICODE) ?>;
        window.JOBY_USER_ROLE = <?= json_encode($_SESSION['user']['role_code'] ?? 'GUEST') ?>;
        window.JOBY_USER_ID = <?= json_encode($_SESSION['user']['account_id'] ?? null) ?>;
        window.JOBY_IS_GUEST = <?= empty($_SESSION['user']) ? 'true' : 'false' ?>;
        window.JOBY_DEFAULT_SUGGESTIONS = <?= json_encode(AIService::generateSuggestionsByContext('', $_SESSION['user']['role_code'] ?? 'GUEST'), JSON_UNESCAPED_UNICODE) ?>;
        window.JOBY_AVATAR_URL = '<?= getJobyAvatar() ?>';
        window.JOBY_LOGIN_URL = '<?= url('/auth/login') ?>';
        window.JOBY_REGISTER_URL = '<?= url('/auth/register') ?>';
        window.JOBY_JOBS_URL = '<?= url('/jobs') ?>';
    </script>
    <script src="<?= asset('js/ai_chatbox.js?v=' . (file_exists(__DIR__ . '/../../js/ai_chatbox.js') ? filemtime(__DIR__ . '/../../js/ai_chatbox.js') : time())) ?>"></script>
    <script src="<?= asset('js/mobile.js') ?>"></script>
    <?php if (!empty($extraJs)): ?>
        <?php foreach ((array)$extraJs as $jsFile): ?>
            <?php
                $jsFsPath = __DIR__ . '/../../' . ltrim($jsFile, '/');
                $jsVer = file_exists($jsFsPath) ? filemtime($jsFsPath) : time();
            ?>
            <script src="<?= asset($jsFile . '?v=' . $jsVer) ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    <?= class_exists('DialogHelper') ? DialogHelper::renderFlashScript() : '' ?>
</body>
</html>
